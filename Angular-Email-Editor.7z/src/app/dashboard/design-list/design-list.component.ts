import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-design-list',
  templateUrl: './design-list.component.html',
  styleUrls: ['./design-list.component.css']
})
export class DesignListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
