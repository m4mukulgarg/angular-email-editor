export class SampleDesign {
  public static designVacation = { "counters": { "u_content_image": 4, "u_content_text": 15, "u_content_divider": 4, "u_content_button": 4, "u_column": 14, "u_row": 11 }, "body": { "rows": [{ "cells": [1], "columns": [{ "contents": [{ "type": "text", "values": { "containerPadding": "10px", "_meta": { "htmlID": "u_content_text_15", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#000000", "textAlign": "left", "lineHeight": "140%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<p style=\"font-size: 14px; line-height: 140%; text-align: center;\"><span style=\"font-size: 72px; line-height: 100.8px; color: #ba372a;\"><strong><span style=\"line-height: 100.8px; font-family: impact, chicago; font-size: 72px;\">PRUDENTIAL</span></strong></span></p>" } }], "values": { "_meta": { "htmlID": "u_column_1", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "10px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_1", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [1], "columns": [{ "contents": [{ "type": "text", "values": { "containerPadding": "10px 10px 5px", "_meta": { "htmlID": "u_content_text_1", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#000", "textAlign": "center", "lineHeight": "120%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<p style=\"font-size: 14px; line-height: 120%;\"><span style=\"color: #f10693; font-family: Pacifico, cursive; font-size: 14px; line-height: 16.8px;\"><strong><span style=\"font-size: 80px; line-height: 96px;\">Group Personal Pension (GPP)<br /></span></strong></span></p>" } }, { "type": "text", "values": { "containerPadding": "10px", "_meta": { "htmlID": "u_content_text_2", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#000", "textAlign": "center", "lineHeight": "120%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<div><span style=\"color: #6fbb7b; font-family: Pacifico, cursive; font-size: 58px; text-align: center; line-height: 69.6px;\">Personal pension plans set up through your employer and provided by us.<br />&nbsp;</span></div>" } }, { "type": "text", "values": { "containerPadding": "20px 10px 9px", "_meta": { "htmlID": "u_content_text_3", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#000", "textAlign": "center", "lineHeight": "140%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<div>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</div>" } }, { "type": "text", "values": { "containerPadding": "5px 10px 10px", "_meta": { "htmlID": "u_content_text_4", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#000", "textAlign": "center", "lineHeight": "160%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<p style=\"font-size: 14px; line-height: 160%;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>" } }, { "type": "divider", "values": { "containerPadding": "20px", "_meta": { "htmlID": "u_content_divider_1", "htmlClassNames": "u_content_divider" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "width": "100%", "border": { "borderTopWidth": "1px", "borderTopStyle": "solid", "borderTopColor": "#CCC" }, "textAlign": "center", "hideDesktop": false, "hideMobile": false } }], "values": { "_meta": { "htmlID": "u_column_2", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "10px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_2", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [1], "columns": [{ "contents": [{ "type": "text", "values": { "containerPadding": "20px", "_meta": { "htmlID": "u_content_text_5", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#000", "textAlign": "left", "lineHeight": "120%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<div><strong><span style=\"font-size: 30px; font-family: Montserrat, sans-serif; color: #2790d2; line-height: 36px;\">Exciting Promos:</span></strong></div>" } }], "values": { "_meta": { "htmlID": "u_column_3", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "0px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_3", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [1, 2], "columns": [{ "contents": [{ "type": "image", "values": { "containerPadding": "0px", "_meta": { "htmlID": "u_content_image_2", "htmlClassNames": "u_content_image" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "src": { "url": "https://a.mailmunch.co/user_data/landing_pages/1500313461528-1.png", "width": 500, "height": 500, "maxWidth": "100%" }, "textAlign": "center", "altText": "Image", "action": { "name": "web", "values": { "href": "", "target": "_blank" }, "url": "", "target": "" }, "hideDesktop": false, "hideMobile": false } }], "values": { "_meta": { "htmlID": "u_column_4", "htmlClassNames": "u_column" } } }, { "contents": [{ "type": "text", "values": { "containerPadding": "10px 15px 8px", "_meta": { "htmlID": "u_content_text_6", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#6eba79", "textAlign": "left", "lineHeight": "160%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<p style=\"font-size: 14px; line-height: 160%;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>" } }, { "type": "text", "values": { "containerPadding": "10px 15px", "_meta": { "htmlID": "u_content_text_7", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#4f4f4f", "textAlign": "left", "lineHeight": "150%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<div>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</div>" } }, { "type": "button", "values": { "containerPadding": "5px 15px", "_meta": { "htmlID": "u_content_button_1", "htmlClassNames": "u_content_button" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "href": "", "buttonColors": { "color": "#FFF", "backgroundColor": "#fa9302", "hoverColor": "#cf7a04", "hoverBackgroundColor": "#3AAEE0" }, "size": { "autoWidth": true, "width": "100%" }, "textAlign": "left", "lineHeight": "120%", "border": {}, "borderRadius": "20px", "padding": "10px 20px", "hideDesktop": false, "hideMobile": false, "calculatedHeight": 36, "calculatedWidth": 149, "text": "ENQUIRE NOW<br />" } }], "values": { "_meta": { "htmlID": "u_column_5", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "10px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_4", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [1], "columns": [{ "contents": [{ "type": "divider", "values": { "containerPadding": "1px 20px 5px", "_meta": { "htmlID": "u_content_divider_2", "htmlClassNames": "u_content_divider" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "width": "100%", "border": { "borderTopWidth": "1px", "borderTopStyle": "solid", "borderTopColor": "#CCC" }, "textAlign": "center", "hideDesktop": false, "hideMobile": false } }], "values": { "_meta": { "htmlID": "u_column_6", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "0px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_5", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [2, 1], "columns": [{ "contents": [{ "type": "text", "values": { "containerPadding": "10px 15px 8px", "_meta": { "htmlID": "u_content_text_8", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#6eba79", "textAlign": "left", "lineHeight": "160%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<p style=\"font-size: 14px; line-height: 160%;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>" } }, { "type": "text", "values": { "containerPadding": "10px 15px", "_meta": { "htmlID": "u_content_text_9", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#4f4f4f", "textAlign": "left", "lineHeight": "150%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<p style=\"font-size: 14px; line-height: 150%;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>" } }, { "type": "button", "values": { "containerPadding": "5px 15px", "_meta": { "htmlID": "u_content_button_2", "htmlClassNames": "u_content_button" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "href": "", "buttonColors": { "color": "#FFF", "backgroundColor": "#fa9302", "hoverColor": "#cf7a04", "hoverBackgroundColor": "#3AAEE0" }, "size": { "autoWidth": true, "width": "100%" }, "textAlign": "left", "lineHeight": "120%", "border": {}, "borderRadius": "20px", "padding": "10px 20px", "hideDesktop": false, "hideMobile": false, "calculatedHeight": 36, "calculatedWidth": 149, "text": "ENQUIRE NOW<br />" } }], "values": { "_meta": { "htmlID": "u_column_7", "htmlClassNames": "u_column" } } }, { "contents": [{ "type": "image", "values": { "containerPadding": "0px", "_meta": { "htmlID": "u_content_image_3", "htmlClassNames": "u_content_image" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "src": { "url": "https://a.mailmunch.co/user_data/landing_pages/1500313783372-2.png", "width": 500, "height": 500, "maxWidth": "100%" }, "textAlign": "center", "altText": "Image", "action": { "name": "web", "values": { "href": "", "target": "_blank" }, "url": "", "target": "" }, "hideDesktop": false, "hideMobile": false } }], "values": { "_meta": { "htmlID": "u_column_8", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "10px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_6", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [1], "columns": [{ "contents": [{ "type": "divider", "values": { "containerPadding": "1px 20px 5px", "_meta": { "htmlID": "u_content_divider_3", "htmlClassNames": "u_content_divider" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "width": "100%", "border": { "borderTopWidth": "1px", "borderTopStyle": "solid", "borderTopColor": "#CCC" }, "textAlign": "center", "hideDesktop": false, "hideMobile": false } }], "values": { "_meta": { "htmlID": "u_column_9", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "0px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_7", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [1, 2], "columns": [{ "contents": [{ "type": "image", "values": { "containerPadding": "0px", "_meta": { "htmlID": "u_content_image_4", "htmlClassNames": "u_content_image" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "src": { "url": "https://a.mailmunch.co/user_data/landing_pages/1500314095876-3.png", "width": 500, "height": 500, "maxWidth": "100%" }, "textAlign": "center", "altText": "Image", "action": { "name": "web", "values": { "href": "", "target": "_blank" }, "url": "", "target": "" }, "hideDesktop": false, "hideMobile": false } }], "values": { "_meta": { "htmlID": "u_column_10", "htmlClassNames": "u_column" } } }, { "contents": [{ "type": "text", "values": { "containerPadding": "10px 15px 8px", "_meta": { "htmlID": "u_content_text_10", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#6eba79", "textAlign": "left", "lineHeight": "160%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<p style=\"font-size: 14px; line-height: 160%;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>" } }, { "type": "text", "values": { "containerPadding": "10px 15px", "_meta": { "htmlID": "u_content_text_11", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#4f4f4f", "textAlign": "left", "lineHeight": "150%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<p style=\"font-size: 14px; line-height: 150%;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>" } }, { "type": "button", "values": { "containerPadding": "5px 15px", "_meta": { "htmlID": "u_content_button_3", "htmlClassNames": "u_content_button" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "href": "", "buttonColors": { "color": "#FFF", "backgroundColor": "#fa9302", "hoverColor": "#cf7a04", "hoverBackgroundColor": "#3AAEE0" }, "size": { "autoWidth": true, "width": "100%" }, "textAlign": "left", "lineHeight": "120%", "border": {}, "borderRadius": "20px", "padding": "10px 20px", "hideDesktop": false, "hideMobile": false, "calculatedHeight": 36, "calculatedWidth": 149, "text": "ENQUIRE NOW<br />" } }], "values": { "_meta": { "htmlID": "u_column_11", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "10px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_8", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [1], "columns": [{ "contents": [{ "type": "divider", "values": { "containerPadding": "1px 20px 5px", "_meta": { "htmlID": "u_content_divider_4", "htmlClassNames": "u_content_divider" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "width": "100%", "border": { "borderTopWidth": "1px", "borderTopStyle": "solid", "borderTopColor": "#CCC" }, "textAlign": "center", "hideDesktop": false, "hideMobile": false } }], "values": { "_meta": { "htmlID": "u_column_12", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "0px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_9", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [1], "columns": [{ "contents": [{ "type": "text", "values": { "containerPadding": "15px", "_meta": { "htmlID": "u_content_text_12", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#fa9302", "textAlign": "center", "lineHeight": "130%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<div><span style=\"font-size: 36px; line-height: 46.8px;\">NEED MORE INFORMATION?</span></div>" } }, { "type": "text", "values": { "containerPadding": "10px", "_meta": { "htmlID": "u_content_text_13", "htmlClassNames": "u_content_text" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "color": "#4f4f4f", "textAlign": "center", "lineHeight": "120%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<div><span style=\"font-size: 20px; line-height: 24px;\">Subscribe to get updates.</span></div>" } }, { "type": "button", "values": { "containerPadding": "20px", "_meta": { "htmlID": "u_content_button_4", "htmlClassNames": "u_content_button" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true, "href": "", "buttonColors": { "color": "#FFF", "backgroundColor": "#6eba79", "hoverColor": "#58a864", "hoverBackgroundColor": "#3AAEE0" }, "size": { "autoWidth": true, "width": "100%" }, "textAlign": "center", "lineHeight": "160%", "border": {}, "borderRadius": "37px", "padding": "10px 20px", "hideDesktop": false, "hideMobile": false, "calculatedHeight": 52, "calculatedWidth": 219, "text": "<span style=\"font-size: 20px; line-height: 32px;\">SUBSCRIBE NOW</span>" } }], "values": { "_meta": { "htmlID": "u_column_13", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "rgba(255,255,255,0)", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "10px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_10", "htmlClassNames": "u_row" }, "selectable": true, "draggable": true, "duplicatable": true, "deletable": true } }, { "cells": [1], "columns": [{ "contents": [{ "type": "text", "values": { "containerPadding": "20px", "_meta": { "htmlID": "u_content_text_14", "htmlClassNames": "u_content_text" }, "selectable": false, "draggable": false, "duplicatable": true, "deletable": false, "color": "#000", "textAlign": "left", "lineHeight": "120%", "linkStyle": { "inherit": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "hideDesktop": false, "hideMobile": false, "text": "<div style=\"font-family: arial, helvetica, sans-serif;\"><span style=\"font-size: 12px; color: #999999; line-height: 14.4px;\">You received this email because you signed up for .</span></div>\n<div style=\"font-family: arial, helvetica, sans-serif;\">&nbsp;</div>\n<div style=\"font-family: arial, helvetica, sans-serif;\"><span style=\"font-size: 12px; color: #999999; line-height: 14.4px;\"></span></div>" } }], "values": { "_meta": { "htmlID": "u_column_14", "htmlClassNames": "u_column" } } }], "values": { "columns": false, "backgroundColor": "#f0f0f0", "columnsBackgroundColor": "rgba(255,255,255,0)", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": false, "cover": false }, "padding": "30px", "hideDesktop": false, "hideMobile": false, "noStackMobile": false, "_meta": { "htmlID": "u_row_11", "htmlClassNames": "u_row" }, "selectable": false, "draggable": false, "duplicatable": true, "deletable": false } }], "values": { "backgroundColor": "#ffffff", "backgroundImage": { "url": "", "fullWidth": true, "repeat": false, "center": true, "cover": false }, "contentWidth": "1200px", "fontFamily": { "label": "Montserrat", "value": "'Montserrat',sans-serif", "type": "google", "weights": "400,700" }, "linkStyle": { "body": true, "linkColor": "#0000ee", "linkHoverColor": "#0000ee", "linkUnderline": true, "linkHoverUnderline": true }, "_meta": { "htmlID": "u_body", "htmlClassNames": "u_body" } } }, "schemaVersion": 5 }

  
  public static bslDesign = {
    "counters": {
      "u_content_image": 5,
      "u_content_text": 18,
      "u_content_divider": 6,
      "u_content_button": 4,
      "u_column": 16,
      "u_row": 12
    },
    "body": {
      "rows": [
        {
          "cells": [
            1
          ],
          "columns": [
            {
              "contents": [
                {
                  "type": "divider",
                  "values": {
                    "containerPadding": "10px",
                    "_meta": {
                      "htmlID": "u_content_divider_5",
                      "htmlClassNames": "u_content_divider"
                    },
                    "selectable": true,
                    "draggable": true,
                    "duplicatable": true,
                    "deletable": true,
                    "width": "100%",
                    "border": {
                      "borderTopWidth": "12px",
                      "borderTopStyle": "solid",
                      "borderTopColor": "#34495e"
                    },
                    "textAlign": "center",
                    "hideDesktop": false,
                    "hideMobile": false
                  }
                }
              ],
              "values": {
                "backgroundColor": "",
                "padding": "0px",
                "border": {},
                "_meta": {
                  "htmlID": "u_column_15",
                  "htmlClassNames": "u_column"
                }
              }
            }
          ],
          "values": {
            "columns": false,
            "backgroundColor": "",
            "columnsBackgroundColor": "",
            "backgroundImage": {
              "url": "",
              "fullWidth": true,
              "repeat": false,
              "center": true,
              "cover": false
            },
            "padding": "0px",
            "hideDesktop": false,
            "hideMobile": false,
            "noStackMobile": false,
            "_meta": {
              "htmlID": "u_row_12",
              "htmlClassNames": "u_row"
            },
            "selectable": true,
            "draggable": true,
            "duplicatable": true,
            "deletable": true
          }
        },
        {
          "cells": [
            2,
            1
          ],
          "columns": [
            {
              "contents": [
                {
                  "type": "text",
                  "values": {
                    "containerPadding": "10px",
                    "_meta": {
                      "htmlID": "u_content_text_17",
                      "htmlClassNames": "u_content_text"
                    },
                    "selectable": true,
                    "draggable": true,
                    "duplicatable": true,
                    "deletable": true,
                    "color": "#000000",
                    "textAlign": "left",
                    "lineHeight": "140%",
                    "linkStyle": {
                      "inherit": true,
                      "linkColor": "#0000ee",
                      "linkHoverColor": "#0000ee",
                      "linkUnderline": true,
                      "linkHoverUnderline": true
                    },
                    "hideDesktop": false,
                    "hideMobile": false,
                    "text": "<p style=\"font-size: 14px; line-height: 140%;\"><span style=\"font-family: helvetica, sans-serif; font-size: 14px; line-height: 19.6px;\"><strong><span style=\"font-size: 14px; line-height: 19.6px;\">BRAVURA SOLUTIONS</span></strong></span></p>\n<p style=\"font-size: 14px; line-height: 140%;\"><span style=\"font-size: 14px; line-height: 19.6px; font-family: helvetica, sans-serif;\">PO Box, 33656 Takapuna, Auckland, New Zealand</span></p>\n<p style=\"font-size: 14px; line-height: 140%;\"><span style=\"font-size: 14px; line-height: 19.6px; font-family: helvetica, sans-serif;\">Call Free 00000000 | Fax: 00000000</span></p>\n<p style=\"font-size: 14px; line-height: 140%;\"><span style=\"font-size: 14px; line-height: 19.6px;\"><a href=\"mailto:conatact@bravurasolutions.com\" target=\"_blank\" rel=\"noopener\">conatact@bravurasolutions.com</a> | <a href=\"https://www.bravurasolutions.com/\" target=\"_blank\" rel=\"noopener\">https://www.bravurasolutions.com/</a></span></p>"
                  }
                }
              ],
              "values": {
                "_meta": {
                  "htmlID": "u_column_1",
                  "htmlClassNames": "u_column"
                }
              }
            },
            {
              "contents": [
                {
                  "type": "image",
                  "values": {
                    "containerPadding": "10px",
                    "_meta": {
                      "htmlID": "u_content_image_5",
                      "htmlClassNames": "u_content_image"
                    },
                    "selectable": true,
                    "draggable": true,
                    "duplicatable": true,
                    "deletable": true,
                    "src": {
                      "url": "https://unroll-images-production.s3.amazonaws.com/projects/0/1597973006796-bsl-logo.png",
                      "width": 231,
                      "height": 78
                    },
                    "textAlign": "center",
                    "altText": "Image",
                    "action": {
                      "name": "web",
                      "values": {
                        "href": "",
                        "target": "_blank"
                      }
                    },
                    "hideDesktop": false,
                    "hideMobile": false
                  }
                }
              ],
              "values": {
                "backgroundColor": "",
                "padding": "0px",
                "border": {},
                "_meta": {
                  "htmlID": "u_column_16",
                  "htmlClassNames": "u_column"
                }
              }
            }
          ],
          "values": {
            "columns": false,
            "backgroundColor": "rgba(255,255,255,0)",
            "columnsBackgroundColor": "rgba(255,255,255,0)",
            "backgroundImage": {
              "url": "",
              "fullWidth": true,
              "repeat": false,
              "center": false,
              "cover": false
            },
            "padding": "10px",
            "hideDesktop": false,
            "hideMobile": false,
            "noStackMobile": false,
            "_meta": {
              "htmlID": "u_row_1",
              "htmlClassNames": "u_row"
            },
            "selectable": true,
            "draggable": true,
            "duplicatable": true,
            "deletable": true
          }
        },
        {
          "cells": [
            1
          ],
          "columns": [
            {
              "contents": [
                {
                  "type": "divider",
                  "values": {
                    "containerPadding": "6px",
                    "_meta": {
                      "htmlID": "u_content_divider_1",
                      "htmlClassNames": "u_content_divider"
                    },
                    "selectable": true,
                    "draggable": true,
                    "duplicatable": true,
                    "deletable": true,
                    "width": "100%",
                    "border": {
                      "borderTopWidth": "5px",
                      "borderTopStyle": "solid",
                      "borderTopColor": "#CCC"
                    },
                    "textAlign": "center",
                    "hideDesktop": false,
                    "hideMobile": false
                  }
                }
              ],
              "values": {
                "_meta": {
                  "htmlID": "u_column_2",
                  "htmlClassNames": "u_column"
                }
              }
            }
          ],
          "values": {
            "columns": false,
            "backgroundColor": "rgba(255,255,255,0)",
            "columnsBackgroundColor": "rgba(255,255,255,0)",
            "backgroundImage": {
              "url": "",
              "fullWidth": true,
              "repeat": false,
              "center": false,
              "cover": false
            },
            "padding": "10px",
            "hideDesktop": false,
            "hideMobile": false,
            "noStackMobile": false,
            "_meta": {
              "htmlID": "u_row_2",
              "htmlClassNames": "u_row"
            },
            "selectable": true,
            "draggable": true,
            "duplicatable": true,
            "deletable": true
          }
        },
        {
          "cells": [
            1
          ],
          "columns": [
            {
              "contents": [
                {
                  "type": "text",
                  "values": {
                    "containerPadding": "10px",
                    "_meta": {
                      "htmlID": "u_content_text_18",
                      "htmlClassNames": "u_content_text"
                    },
                    "selectable": true,
                    "draggable": true,
                    "duplicatable": true,
                    "deletable": true,
                    "color": "#000000",
                    "textAlign": "left",
                    "lineHeight": "140%",
                    "linkStyle": {
                      "inherit": true,
                      "linkColor": "#0000ee",
                      "linkHoverColor": "#0000ee",
                      "linkUnderline": true,
                      "linkHoverUnderline": true
                    },
                    "hideDesktop": false,
                    "hideMobile": false,
                    "text": "<p style=\"font-size: 14px; line-height: 140%;\"><span style=\"font-size: 14px; line-height: 19.6px;\">14 January 2014</span></p>\n<p style=\"font-size: 14px; line-height: 140%;\"><span style=\"font-size: 14px; line-height: 19.6px;\">{{clnt_forename}} {{clnt_surname}}</span></p>\n<p style=\"font-size: 14px; line-height: 140%;\"><span style=\"font-size: 14px; line-height: 19.6px;\">{{addr_street}}</span></p>\n<p style=\"font-size: 14px; line-height: 140%;\"><span style=\"font-size: 14px; line-height: 19.6px;\">{{addr_locality}}</span></p>\n<p style=\"font-size: 14px; line-height: 140%;\"><span style=\"font-size: 14px; line-height: 19.6px;\">{{addr_postcode}}</span></p>"
                  }
                }
              ],
              "values": {
                "_meta": {
                  "htmlID": "u_column_6",
                  "htmlClassNames": "u_column"
                }
              }
            }
          ],
          "values": {
            "columns": false,
            "backgroundColor": "rgba(255,255,255,0)",
            "columnsBackgroundColor": "rgba(255,255,255,0)",
            "backgroundImage": {
              "url": "",
              "fullWidth": true,
              "repeat": false,
              "center": false,
              "cover": false
            },
            "padding": "0px",
            "hideDesktop": false,
            "hideMobile": false,
            "noStackMobile": false,
            "_meta": {
              "htmlID": "u_row_5",
              "htmlClassNames": "u_row"
            },
            "selectable": true,
            "draggable": true,
            "duplicatable": true,
            "deletable": true
          }
        },
        {
          "cells": [
            1
          ],
          "columns": [
            {
              "contents": [
                {
                  "type": "divider",
                  "values": {
                    "containerPadding": "10px",
                    "_meta": {
                      "htmlID": "u_content_divider_6",
                      "htmlClassNames": "u_content_divider"
                    },
                    "selectable": true,
                    "draggable": true,
                    "duplicatable": true,
                    "deletable": true,
                    "width": "100%",
                    "border": {
                      "borderTopWidth": "2px",
                      "borderTopStyle": "solid",
                      "borderTopColor": "#BBBBBB"
                    },
                    "textAlign": "center",
                    "hideDesktop": false,
                    "hideMobile": false
                  }
                }
              ],
              "values": {
                "_meta": {
                  "htmlID": "u_column_9",
                  "htmlClassNames": "u_column"
                }
              }
            }
          ],
          "values": {
            "columns": false,
            "backgroundColor": "rgba(255,255,255,0)",
            "columnsBackgroundColor": "rgba(255,255,255,0)",
            "backgroundImage": {
              "url": "",
              "fullWidth": true,
              "repeat": false,
              "center": false,
              "cover": false
            },
            "padding": "0px",
            "hideDesktop": false,
            "hideMobile": false,
            "noStackMobile": false,
            "_meta": {
              "htmlID": "u_row_7",
              "htmlClassNames": "u_row"
            },
            "selectable": true,
            "draggable": true,
            "duplicatable": true,
            "deletable": true
          }
        },
        {
          "cells": [
            1
          ],
          "columns": [
            {
              "contents": [
                {
                  "type": "text",
                  "values": {
                    "containerPadding": "10px",
                    "_meta": {
                      "htmlID": "u_content_text_13",
                      "htmlClassNames": "u_content_text"
                    },
                    "selectable": true,
                    "draggable": true,
                    "duplicatable": true,
                    "deletable": true,
                    "color": "#4f4f4f",
                    "textAlign": "center",
                    "lineHeight": "120%",
                    "linkStyle": {
                      "inherit": true,
                      "linkColor": "#0000ee",
                      "linkHoverColor": "#0000ee",
                      "linkUnderline": true,
                      "linkHoverUnderline": true
                    },
                    "hideDesktop": false,
                    "hideMobile": false,
                    "text": "<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-family: 'times new roman', times; font-size: 14px; line-height: 16.8px; color: #000000;\">Dear Mr. {{clnt_forename}} {{clnt_surname}}</span></p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\">&nbsp;</p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-family: 'times new roman', times; font-size: 14px; line-height: 16.8px; color: #000000;\">Please find below your customer id to access your {{product}} account online.</span></p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\">&nbsp;</p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-size: 16px; line-height: 19.2px; font-family: 'times new roman', times; color: #000000;\"><strong>Customer ID: {{clnt_id}}</strong></span></p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\">&nbsp;</p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-size: 14px; line-height: 16.8px; font-family: 'times new roman', times; color: #000000;\">Use this along with your password (sent to you separately).</span></p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\">&nbsp;</p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-size: 14px; line-height: 16.8px; font-family: 'times new roman', times; color: #000000;\">If you require any assistance in registering online, please contact our Client Services Team on 0000000.</span></p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-size: 14px; line-height: 16.8px; font-family: 'times new roman', times; color: #000000;\">If you have any queries please contact out Client Services Team on 11111111111.</span></p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-size: 14px; line-height: 16.8px; font-family: 'times new roman', times; color: #000000;\">Yours sincerely</span></p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\">&nbsp;</p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-size: 14px; line-height: 16.8px; font-family: 'times new roman', times; color: #000000;\">Digitally signed by&nbsp;</span></p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-size: 14px; line-height: 16.8px; font-family: 'times new roman', times; color: #000000;\">Demonstration User</span></p>\n<p style=\"font-size: 14px; line-height: 120%; text-align: left;\"><span style=\"font-size: 10px; line-height: 12px; font-family: 'times new roman', times; color: #000000;\">[Digital Fingerprint ID: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx]</span></p>"
                  }
                },
                {
                  "type": "button",
                  "values": {
                    "containerPadding": "20px",
                    "_meta": {
                      "htmlID": "u_content_button_4",
                      "htmlClassNames": "u_content_button"
                    },
                    "selectable": true,
                    "draggable": true,
                    "duplicatable": true,
                    "deletable": true,
                    "href": "",
                    "buttonColors": {
                      "color": "#FFF",
                      "backgroundColor": "#6eba79",
                      "hoverColor": "#58a864",
                      "hoverBackgroundColor": "#3AAEE0"
                    },
                    "size": {
                      "autoWidth": true,
                      "width": "100%"
                    },
                    "textAlign": "center",
                    "lineHeight": "160%",
                    "border": {},
                    "borderRadius": "37px",
                    "padding": "10px 20px",
                    "hideDesktop": false,
                    "hideMobile": false,
                    "calculatedHeight": 52,
                    "calculatedWidth": 219,
                    "text": "<span style=\"font-size: 20px; line-height: 32px;\">SUBSCRIBE NOW</span>"
                  }
                }
              ],
              "values": {
                "_meta": {
                  "htmlID": "u_column_13",
                  "htmlClassNames": "u_column"
                }
              }
            }
          ],
          "values": {
            "columns": false,
            "backgroundColor": "rgba(255,255,255,0)",
            "columnsBackgroundColor": "rgba(255,255,255,0)",
            "backgroundImage": {
              "url": "",
              "fullWidth": true,
              "repeat": false,
              "center": false,
              "cover": false
            },
            "padding": "10px",
            "hideDesktop": false,
            "hideMobile": false,
            "noStackMobile": false,
            "_meta": {
              "htmlID": "u_row_10",
              "htmlClassNames": "u_row"
            },
            "selectable": true,
            "draggable": true,
            "duplicatable": true,
            "deletable": true
          }
        },
        {
          "cells": [
            1
          ],
          "columns": [
            {
              "contents": [
                {
                  "type": "text",
                  "values": {
                    "containerPadding": "20px",
                    "_meta": {
                      "htmlID": "u_content_text_14",
                      "htmlClassNames": "u_content_text"
                    },
                    "selectable": false,
                    "draggable": false,
                    "duplicatable": true,
                    "deletable": false,
                    "color": "#000",
                    "textAlign": "left",
                    "lineHeight": "120%",
                    "linkStyle": {
                      "inherit": true,
                      "linkColor": "#0000ee",
                      "linkHoverColor": "#0000ee",
                      "linkUnderline": true,
                      "linkHoverUnderline": true
                    },
                    "hideDesktop": false,
                    "hideMobile": false,
                    "text": "<div style=\"font-family: arial, helvetica, sans-serif;\"><span style=\"font-size: 12px; color: #999999; line-height: 14.4px;\">You received this email because you signed up for .</span></div>\n<div style=\"font-family: arial, helvetica, sans-serif;\">&nbsp;</div>\n<div style=\"font-family: arial, helvetica, sans-serif;\"><span style=\"font-size: 12px; color: #999999; line-height: 14.4px;\"></span></div>"
                  }
                }
              ],
              "values": {
                "_meta": {
                  "htmlID": "u_column_14",
                  "htmlClassNames": "u_column"
                }
              }
            }
          ],
          "values": {
            "columns": false,
            "backgroundColor": "#f0f0f0",
            "columnsBackgroundColor": "rgba(255,255,255,0)",
            "backgroundImage": {
              "url": "",
              "fullWidth": true,
              "repeat": false,
              "center": false,
              "cover": false
            },
            "padding": "30px",
            "hideDesktop": false,
            "hideMobile": false,
            "noStackMobile": false,
            "_meta": {
              "htmlID": "u_row_11",
              "htmlClassNames": "u_row"
            },
            "selectable": false,
            "draggable": false,
            "duplicatable": true,
            "deletable": false
          }
        }
      ],
      "values": {
        "backgroundColor": "#ffffff",
        "backgroundImage": {
          "url": "",
          "fullWidth": true,
          "repeat": false,
          "center": true,
          "cover": false
        },
        "contentWidth": "700px",
        "fontFamily": {
          "label": "Montserrat",
          "value": "'Montserrat',sans-serif",
          "type": "google",
          "weights": "400,700"
        },
        "linkStyle": {
          "body": true,
          "linkColor": "#0000ee",
          "linkHoverColor": "#0000ee",
          "linkUnderline": true,
          "linkHoverUnderline": true
        },
        "_meta": {
          "htmlID": "u_body",
          "htmlClassNames": "u_body"
        }
      }
    },
    "schemaVersion": 5
  }


}